
import React from 'react';
import { HistoryItem } from '../types';
import { Database, Shield, Globe, ExternalLink, Trash2 } from 'lucide-react';

interface AdminDashboardProps {
  history: HistoryItem[];
  onClear: () => void;
  onSelect: (url: string) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ history, onClear, onSelect }) => {
  return (
    <div className="space-y-6 animate-in fade-in zoom-in-95 duration-500">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Database className="text-green-500" size={24} />
          <h2 className="text-xl font-bold uppercase tracking-widest text-green-400">System Logs</h2>
        </div>
        <button 
          onClick={onClear}
          className="text-[10px] text-red-500 hover:text-red-400 border border-red-500/20 px-3 py-1 rounded transition-all"
        >
          PURGE DATABASE
        </button>
      </div>

      <div className="bg-black/60 border border-green-500/10 rounded-xl overflow-hidden backdrop-blur-md">
        <table className="w-full text-left text-xs border-collapse">
          <thead>
            <tr className="bg-green-500/5 text-green-800 uppercase tracking-tighter">
              <th className="p-4 font-mono">Timestamp</th>
              <th className="p-4 font-mono">Target Host</th>
              <th className="p-4 font-mono">Node IP</th>
              <th className="p-4 font-mono text-center">Score</th>
              <th className="p-4 font-mono text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-green-500/5">
            {history.map((item) => (
              <tr key={item.id} className="hover:bg-green-500/5 transition-colors group">
                <td className="p-4 text-green-900 font-mono">{new Date(item.timestamp).toLocaleString()}</td>
                <td className="p-4 text-cyan-400 font-bold">{item.url}</td>
                <td className="p-4 text-gray-500">{item.ip}</td>
                <td className="p-4 text-center">
                  <span className={`px-2 py-0.5 rounded ${item.score > 80 ? 'bg-green-900/20 text-green-400' : 'bg-yellow-900/20 text-yellow-400'}`}>
                    {item.score}%
                  </span>
                </td>
                <td className="p-4 text-right">
                  <button 
                    onClick={() => onSelect(item.url)}
                    className="p-1 hover:text-cyan-400 transition-colors"
                  >
                    <ExternalLink size={14} />
                  </button>
                </td>
              </tr>
            ))}
            {history.length === 0 && (
              <tr>
                <td colSpan={5} className="p-12 text-center text-green-900 italic font-mono">
                  No scan logs present in local storage.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-black/40 border border-green-500/10 p-6 rounded-lg text-center">
          <Shield className="mx-auto mb-2 text-green-700" size={32} />
          <div className="text-2xl font-bold text-green-400">{history.length}</div>
          <div className="text-[10px] text-green-900 uppercase">Total Scans</div>
        </div>
        <div className="bg-black/40 border border-green-500/10 p-6 rounded-lg text-center">
          <Globe className="mx-auto mb-2 text-cyan-700" size={32} />
          <div className="text-2xl font-bold text-cyan-400">
            {new Set(history.map(h => h.ip)).size}
          </div>
          <div className="text-[10px] text-green-900 uppercase">Unique Nodes</div>
        </div>
        <div className="bg-black/40 border border-green-500/10 p-6 rounded-lg text-center">
          <Trash2 className="mx-auto mb-2 text-red-700" size={32} />
          <div className="text-2xl font-bold text-red-400">SECURE</div>
          <div className="text-[10px] text-green-900 uppercase">Database Status</div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
