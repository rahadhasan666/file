
import React from 'react';
import { ScanResult } from '../types';
import { Shield, Server, Globe, Activity, Lock, Users, ExternalLink, Download } from 'lucide-react';

interface ResultViewProps {
  result: ScanResult;
  onExport: () => void;
}

const ResultView: React.FC<ResultViewProps> = ({ result, onExport }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12 animate-in fade-in slide-in-from-bottom-4 duration-700">
      
      {/* Basic Info */}
      <div className="bg-black/60 border border-green-500/20 p-6 rounded-lg hover:border-green-500/50 transition-all group">
        <div className="flex items-center gap-3 mb-4 text-green-400">
          <Server size={20} />
          <h3 className="font-bold uppercase tracking-widest text-sm">Infrastructure</h3>
        </div>
        <div className="space-y-3 text-sm">
          <p><span className="text-gray-500">IP Addr:</span> <span className="text-cyan-400">{result.ip}</span></p>
          <p><span className="text-gray-500">Server:</span> {result.server}</p>
          <p><span className="text-gray-500">Location:</span> {result.location}</p>
          <p><span className="text-gray-500">ISP:</span> {result.isp}</p>
          <p><span className="text-gray-500">CDN:</span> {result.cdn}</p>
        </div>
      </div>

      {/* SSL Status */}
      <div className="bg-black/60 border border-green-500/20 p-6 rounded-lg hover:border-green-500/50 transition-all">
        <div className="flex items-center gap-3 mb-4 text-green-400">
          <Lock size={20} />
          <h3 className="font-bold uppercase tracking-widest text-sm">Security & SSL</h3>
        </div>
        <div className="space-y-3 text-sm">
          <div className="flex items-center gap-2">
            <span className="text-gray-500">Status:</span>
            {result.ssl.valid ? (
              <span className="px-2 py-0.5 bg-green-900/40 text-green-400 rounded text-xs border border-green-500/50">ENCRYPTED</span>
            ) : (
              <span className="px-2 py-0.5 bg-red-900/40 text-red-400 rounded text-xs border border-red-500/50">VULNERABLE</span>
            )}
          </div>
          <p><span className="text-gray-500">Issuer:</span> {result.ssl.issuer}</p>
          <p><span className="text-gray-500">Expires:</span> {result.ssl.expiry}</p>
          <p><span className="text-gray-500">Score:</span> <span className="text-green-400 font-bold">{result.securityScore}%</span></p>
        </div>
      </div>

      {/* Traffic Stats */}
      <div className="bg-black/60 border border-green-500/20 p-6 rounded-lg hover:border-green-500/50 transition-all">
        <div className="flex items-center gap-3 mb-4 text-green-400">
          <Users size={20} />
          <h3 className="font-bold uppercase tracking-widest text-sm">Traffic Metrics</h3>
        </div>
        <div className="space-y-3 text-sm">
          <p><span className="text-gray-500">Visitors/Mo:</span> <span className="text-green-400">{result.traffic.monthlyVisitors}</span></p>
          <p><span className="text-gray-500">Bounce Rate:</span> {result.traffic.bounceRate}</p>
          <p className="text-gray-500 mb-1">Origin Distribution:</p>
          <div className="flex flex-wrap gap-2">
            {result.traffic.topCountries.map(c => (
              <span key={c} className="text-[10px] bg-green-500/10 border border-green-500/30 px-2 py-1 rounded">{c}</span>
            ))}
          </div>
        </div>
      </div>

      {/* HTTP Headers */}
      <div className="col-span-1 md:col-span-2 lg:col-span-3 bg-black/60 border border-green-500/20 p-6 rounded-lg">
        <div className="flex items-center justify-between mb-4 text-green-400">
          <div className="flex items-center gap-3">
            <Activity size={20} />
            <h3 className="font-bold uppercase tracking-widest text-sm">HTTP Response Headers</h3>
          </div>
          <button 
            onClick={onExport}
            className="flex items-center gap-2 text-xs text-cyan-400 hover:text-cyan-300 border border-cyan-400/30 px-3 py-1 rounded transition-colors"
          >
            <Download size={14} /> EXPORT PDF
          </button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs font-mono">
          {Object.entries(result.headers).map(([key, value]) => (
            <div key={key} className="bg-white/5 p-3 rounded border border-white/5 overflow-hidden text-ellipsis">
              <span className="text-green-600 block mb-1">{key}</span>
              <span className="text-gray-300 break-all">{value}</span>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};

export default ResultView;
