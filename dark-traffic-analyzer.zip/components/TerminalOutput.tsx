
import React, { useState, useEffect } from 'react';

interface TerminalOutputProps {
  logs: string[];
}

const TerminalOutput: React.FC<TerminalOutputProps> = ({ logs }) => {
  const [visibleLogs, setVisibleLogs] = useState<string[]>([]);

  useEffect(() => {
    setVisibleLogs([]);
    let i = 0;
    const interval = setInterval(() => {
      if (i < logs.length) {
        setVisibleLogs(prev => [...prev, logs[i]]);
        i++;
      } else {
        clearInterval(interval);
      }
    }, 150);

    return () => clearInterval(interval);
  }, [logs]);

  return (
    <div className="bg-black/80 border border-green-500/30 p-4 rounded font-mono text-xs leading-relaxed overflow-hidden h-48 mb-6 relative">
      <div className="scanner-line"></div>
      {visibleLogs.map((log, index) => (
        <div key={index} className="flex gap-2">
          <span className="text-green-800">[{new Date().toLocaleTimeString()}]</span>
          <span className="text-cyan-400">$ {log}</span>
        </div>
      ))}
      {visibleLogs.length > 0 && (
        <div className="animate-pulse inline-block w-2 h-4 bg-green-500 ml-1"></div>
      )}
    </div>
  );
};

export default TerminalOutput;
