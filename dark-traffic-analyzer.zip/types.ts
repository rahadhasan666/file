
export interface ScanResult {
  id: string;
  url: string;
  timestamp: string;
  ip: string;
  server: string;
  location: string;
  isp: string;
  ssl: {
    valid: boolean;
    issuer: string;
    expiry: string;
    encryptionStrength: string;
  };
  headers: Record<string, string>;
  responseTime: number;
  openPorts: {
    port: number;
    service: string;
    // Fix: Added 'CLOSED' to the status union type to accurately report port states in the diagnostic results
    status: 'OPEN' | 'CLOSED' | 'FILTERED';
  }[];
  cdn: string;
  traffic: {
    monthlyVisitors: string;
    bounceRate: string;
    topCountries: string[];
    avgSessionDuration: string;
  };
  securityScore: number;
  vulnerabilities: string[];
}

export interface HistoryItem {
  id: string;
  url: string;
  timestamp: string;
  ip: string;
  score: number;
}