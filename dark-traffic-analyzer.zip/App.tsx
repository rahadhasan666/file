
import React, { useState, useEffect, useCallback } from 'react';
import { Search, Shield, Cpu, Globe, Github, Terminal, Lock, LogIn, Database, LogOut, LayoutDashboard, Radar, Activity, Zap } from 'lucide-react';
import CyberBackground from './components/CyberBackground';
import TerminalOutput from './components/TerminalOutput';
import ResultView from './components/ResultView';
import AdminDashboard from './components/AdminDashboard';
import { analyzeWebsite } from './services/geminiService';
import { ScanResult, HistoryItem } from './types';

type ViewState = 'SCANNER' | 'DASHBOARD' | 'AUTH';

function App() {
  const [url, setUrl] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [logs, setLogs] = useState<string[]>([]);
  const [currentResult, setCurrentResult] = useState<ScanResult | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [activeView, setActiveView] = useState<ViewState>('SCANNER');
  const [isAdmin, setIsAdmin] = useState(false);
  const [password, setPassword] = useState('');

  useEffect(() => {
    const saved = localStorage.getItem('dark_traffic_v3_history');
    if (saved) setHistory(JSON.parse(saved));
  }, []);

  const saveToHistory = useCallback((result: ScanResult) => {
    const newItem: HistoryItem = {
      id: result.id,
      url: result.url,
      timestamp: result.timestamp,
      ip: result.ip,
      score: result.securityScore
    };
    const updated = [newItem, ...history].slice(0, 50);
    setHistory(updated);
    localStorage.setItem('dark_traffic_v3_history', JSON.stringify(updated));
  }, [history]);

  const clearHistory = useCallback(() => {
    if (confirm('Permanently purge all scan logs?')) {
      setHistory([]);
      localStorage.removeItem('dark_traffic_v3_history');
    }
  }, []);

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url || isScanning) return;

    let target = url.trim();
    setIsScanning(true);
    setProgress(0);
    setCurrentResult(null);
    setActiveView('SCANNER');
    
    setLogs([
      'STARTING LIVE NETWORK DIAGNOSTICS...',
      `QUERYING DNS-OVER-HTTPS FOR: ${target.toUpperCase()}`,
      'RESOLVING HOSTNAME TO IPV4...',
      'LOCATING PHYSICAL DATA CENTER...',
      'INSPECTING ASN ROUTING TABLES...',
      'VERIFYING TLS/SSL CERTIFICATE...',
      'CALCULATING PACKET ROUND-TRIP TIME...'
    ]);

    const timer = setInterval(() => {
      setProgress(p => (p >= 90 ? 90 : p + 5));
    }, 200);

    try {
      const result = await analyzeWebsite(target);
      clearInterval(timer);
      setProgress(100);
      setCurrentResult(result);
      saveToHistory(result);
      setLogs(prev => [...prev, '✓ LIVE DATA RETRIEVED', 'PARSING INFRASTRUCTURE MAP...', 'READY.']);
    } catch (err: any) {
      clearInterval(timer);
      setProgress(0);
      setLogs(prev => [
        ...prev, 
        '!! NETWORK_LAYER_ERROR !!', 
        `CODE: ${err.message || 'Lookup timeout.'}`,
        'SYSTEM STANDBY.'
      ]);
    } finally {
      setIsScanning(false);
    }
  };

  const handleAdminAuth = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === 'admin123') {
      setIsAdmin(true);
      setActiveView('DASHBOARD');
      setPassword('');
    } else {
      alert('ACCESS DENIED');
    }
  };

  return (
    <div className="min-h-screen text-green-500 p-4 md:p-8 relative overflow-x-hidden font-mono">
      <CyberBackground />

      <header className="max-w-6xl mx-auto mb-10 flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10 border-b border-green-500/10 pb-6">
        <div className="flex items-center gap-4 group cursor-pointer" onClick={() => setActiveView('SCANNER')}>
          <div className="p-3 bg-green-500/5 border border-green-500/20 rounded-xl group-hover:border-green-500/60 transition-all shadow-[0_0_15px_rgba(0,255,65,0.1)]">
            <Zap size={32} className="text-yellow-400 animate-pulse" />
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-tighter text-white uppercase group-hover:text-green-400 transition-colors">Dark Traffic</h1>
            <p className="text-[10px] text-green-700 font-mono tracking-[0.3em]">LIVE REAL-TIME DIAGNOSTICS</p>
          </div>
        </div>

        <nav className="flex items-center gap-2 bg-black/60 p-1 rounded-lg border border-green-500/10 backdrop-blur-md">
          <button 
            onClick={() => setActiveView('SCANNER')}
            className={`px-6 py-2 rounded-md text-xs font-bold transition-all flex items-center gap-2 ${activeView === 'SCANNER' ? 'bg-green-600 text-black shadow-[0_0_20px_rgba(0,255,65,0.4)]' : 'text-green-700 hover:text-green-400'}`}
          >
            <Activity size={14} /> LIVE_SCAN
          </button>
          <button 
            onClick={() => isAdmin ? setActiveView('DASHBOARD') : setActiveView('AUTH')}
            className={`px-6 py-2 rounded-md text-xs font-bold transition-all flex items-center gap-2 ${activeView === 'DASHBOARD' || activeView === 'AUTH' ? 'bg-green-600 text-black shadow-[0_0_20px_rgba(0,255,65,0.4)]' : 'text-green-700 hover:text-green-400'}`}
          >
            <LayoutDashboard size={14} /> ADMIN_LOGS
          </button>
        </nav>
      </header>

      <main className="max-w-6xl mx-auto relative z-10 pb-20">
        
        {activeView === 'SCANNER' && (
          <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
            <section className="mb-12 bg-black/60 p-8 rounded-2xl border border-green-500/10 backdrop-blur-xl relative overflow-hidden shadow-2xl">
              <div className="absolute top-0 right-0 p-4 opacity-10 pointer-events-none">
                <Radar size={150} className="text-green-500 animate-spin-slow" />
              </div>
              
              <div className="flex items-center gap-2 mb-6">
                <Terminal size={16} className="text-green-700" />
                <h2 className="text-xs font-bold text-green-700 uppercase tracking-widest">Network Entry Point</h2>
              </div>

              <form onSubmit={handleScan} className="flex flex-col md:flex-row gap-4 relative z-10">
                <div className="relative flex-1">
                  <Globe className="absolute left-4 top-1/2 -translate-y-1/2 text-green-900" size={20} />
                  <input 
                    type="text" 
                    placeholder="Enter target (e.g., google.com)..."
                    className="w-full bg-black/80 border border-green-500/20 rounded-xl py-4 pl-12 pr-4 outline-none focus:border-green-500 focus:shadow-[0_0_20px_rgba(0,255,65,0.1)] transition-all text-green-400 font-mono text-sm"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    disabled={isScanning}
                  />
                </div>
                <button 
                  type="submit"
                  disabled={isScanning || !url}
                  className="bg-green-600 hover:bg-green-500 disabled:bg-gray-800 text-black font-black px-12 rounded-xl flex items-center justify-center gap-3 transition-all uppercase tracking-tighter h-[56px] shadow-lg"
                >
                  {isScanning ? <div className="animate-spin rounded-full h-5 w-5 border-2 border-black border-t-transparent" /> : <Radar size={20} />}
                  {isScanning ? 'PROBING...' : 'LIVE AUDIT'}
                </button>
              </form>

              {(isScanning || logs.length > 0) && (
                <div className="mt-8 space-y-3 relative z-10">
                  <div className="flex justify-between items-end">
                    <span className="text-[10px] font-mono text-cyan-400 uppercase">
                      Network Packet Capture: {Math.floor(progress)}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-black rounded-full border border-green-500/10 overflow-hidden">
                    <div 
                      className="h-full bg-green-500 transition-all duration-300" 
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>
              )}
            </section>

            {(isScanning || (logs.length > 0 && !currentResult)) && <TerminalOutput logs={logs} />}
            
            {currentResult && !isScanning && (
              <ResultView result={currentResult} onExport={() => window.print()} />
            )}
          </div>
        )}

        {activeView === 'DASHBOARD' && isAdmin && (
          <AdminDashboard history={history} onClear={clearHistory} onSelect={(u) => { setUrl(u); setActiveView('SCANNER'); }} />
        )}

        {activeView === 'AUTH' && (
          <div className="flex justify-center py-20">
            <div className="bg-black/90 border border-green-500/20 p-10 rounded-2xl w-full max-w-md shadow-2xl backdrop-blur-2xl">
              <h2 className="text-2xl font-black text-white uppercase text-center mb-8">Access Logs</h2>
              <form onSubmit={handleAdminAuth} className="space-y-6">
                <input 
                  type="password" 
                  placeholder="Access Code"
                  className="w-full bg-black border border-green-500/20 rounded-xl p-4 text-center text-green-400 outline-none focus:border-green-500 font-mono tracking-widest"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <button type="submit" className="w-full py-4 bg-green-600 text-black font-black rounded-xl hover:bg-green-500">AUTH & ENTER</button>
              </form>
            </div>
          </div>
        )}
      </main>

      <footer className="mt-auto border-t border-green-500/5 py-10 relative z-10">
        <div className="max-w-6xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-6">
          <p className="text-xs font-mono text-green-700">MADE BY <a href="https://github.com/rahadhasan" target="_blank" className="text-white hover:text-green-400 font-black transition-colors">RAHAD HASAN <Github size={14} className="inline ml-1" /></a></p>
          <div className="flex items-center gap-6 text-[10px] font-mono text-green-900 uppercase">
            <span>LIVE_NETWORK_API: CONNECTED</span>
            <span>DNS_OVER_HTTPS: ACTIVE</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
